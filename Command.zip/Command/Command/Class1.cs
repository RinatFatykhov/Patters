﻿using System;
using System.Threading.Tasks;

namespace Command
{
    /// <summary>
    /// клиент - создает команду и устанавливает ее получателя с помощью метода SetCommand()
    /// </summary>
    class Client
    {
        static void Main(string[] args)
        {
            Pult pult = new Pult();
            TV tv = new TV();
            pult.SetCommand(new TVOnCommand(tv));
            pult.PressButton();
            pult.PressUndo();

            Microwave microwave = new Microwave();
            // 5000 - время нагрева пищи
            pult.SetCommand(new MicrowaveCommand(microwave, 5000));
            pult.PressButton();

            Console.Read();
        }
    }
    /// <summary>
    /// интерфейс для команды выполнить/отменить, без привязки к определенному объекту
    /// </summary>
    interface ICommand
    {
        void Execute();
        void Undo();
    }

    // Receiver - Получатель
    /// <summary>
    /// получатель команды - определяет действия, которые должны выполняться в результате запроса.
    /// </summary>
    class TV
    {
        public void On()
        {
            Console.WriteLine("Телевизор включен!");
        }

        public void Off()
        {
            Console.WriteLine("Телевизор выключен...");
        }
    }
    /// <summary>
    /// реализация интерфейса ICommand для объекта TV(телевизор)
    /// </summary>
    class TVOnCommand : ICommand
    {
        /// <summary>
        /// телевизор, которому будут отправляться команды на включение и выключение
        /// </summary>
        TV tv;
        /// <summary>
        /// конструктор, получает ссылку на определенный объект TV
        /// </summary>
        /// <param name="tvSet"></param>
        public TVOnCommand(TV tvSet)
        {
            tv = tvSet;
        }
        /// <summary>
        /// команда на включение телевизора
        /// </summary>
        public void Execute()
        {
            tv.On();
        }
        /// <summary>
        /// команда на выключение телевизора
        /// </summary>
        public void Undo()
        {
            tv.Off();
        }
    }

    // Invoker - инициатор
    /// <summary>
    /// инициатор, который может отправлять запрос на выполнение определенной команды каким-то объектам, неизвестным для него
    /// </summary>
    class Pult
    {
        ICommand command;

        public Pult() { }
        /// <summary>
        /// инициализация запроса с привязкой к команде определенного объекта
        /// </summary>
        /// <param name="com"></param>
        public void SetCommand(ICommand com)
        {
            command = com;
        }
        /// <summary>
        /// запрос на выполнение дейстия команды
        /// </summary>
        public void PressButton()
        {
            command.Execute();
        }
        /// <summary>
        /// запрос на отмену действия команды
        /// </summary>
        public void PressUndo()
        {
            command.Undo();
        }
    }
    /// <summary>
    /// получатель команды - определяет действия, которые должны выполняться в результате запроса.
    /// </summary>
    class Microwave
    {
        public void StartCooking(int time)
        {
            Console.WriteLine("Подогреваем еду");
            // имитация работы с помощью асинхронного метода Task.Delay
            Task.Delay(time).GetAwaiter().GetResult();
        }

        public void StopCooking()
        {
            Console.WriteLine("Еда подогрета!");
        }
    }
    /// <summary>
    /// реализация интерфейса ICommand для объекта Microwave(микроволновка)
    /// </summary>
    class MicrowaveCommand : ICommand
    {
        /// <summary>
        /// микроволновка, которой будут отправляться команды на включение и выключение
        /// </summary>
        Microwave microwave;
        /// <summary>
        /// время готовки
        /// </summary>
        int time;
        /// <summary>
        /// конструктор, принимающий ссылку на определенный объект Microwave
        /// </summary>
        /// <param name="m"></param>
        /// <param name="t"></param>
        public MicrowaveCommand(Microwave m, int t)
        {
            microwave = m;
            time = t;
        }
        /// <summary>
        /// команда на процесс подогревания пищи
        /// </summary>
        public void Execute()
        {
            microwave.StartCooking(time);
            microwave.StopCooking();
        }
        /// <summary>
        /// команда на отмену процесса подогревания пищи
        /// </summary>
        public void Undo()
        {
            microwave.StopCooking();
        }
    }
}
